from flask import Flask, render_template, redirect
from flask_login import LoginManager, login_user, login_required, logout_user
from data import db_session
from data.login import LoginForm
from data.users import User
from data.register import RegisterForm

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'
login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/')
def menu():
    return render_template('menu.html')


@app.route('/theory')
def theory():
    return render_template('theory.html')


@app.route('/theory_15')
def theory15():
    return render_template('theory_15.html')


@app.route('/theory_19')
def theory19():
    return render_template('theory_19.html')


@app.route('/task')
def task():
    return render_template('task.html')


@app.route('/task_21')
def task_21():
    return render_template('task_21.html')


@app.route('/task_15')
def task_15():
    return render_template('task_15.html')


@app.route('/task_19')
def task_19():
    return render_template('task_19.html')


@app.route('/task_20')
def task_20():
    return render_template('task_20.html')


@app.route('/answer_15')
def answer_15():
    return render_template('answer_15.html')


@app.route('/answer_19')
def answer_19():
    return render_template('answer_19.html')


@app.route('/answer_20')
def answer_20():
    return render_template('answer_20.html')


@app.route('/answer_21')
def answer_21():
    return render_template('answer_21.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html', message="Wrong login or password", form=form)
    return render_template('login.html', title='Authorization', form=form)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Register', form=form,
                                   message="Passwords don't match")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Register', form=form,
                                   message="This user already exists")
        user = User(
            name=form.name.data,
            surname=form.surname.data,
            age=form.age.data,
            position=form.position.data,
            email=form.email.data,
            speciality=form.speciality.data,
            address=form.address.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


def main():
    db_session.global_init("db_ege.sqlite")

    app.run()


if __name__ == '__main__':
    app.run()
